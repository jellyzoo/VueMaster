<template>
  <main class="mt-3">
    <div class="container">
      <div class="row mb-2">
        <div class="col-12">
          <select class="form-select">
            <option selected></option>
            <option value="1">NEW7%</option>
            <option value="2">BEST</option>
            <option value="3">MADE</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <a><img src="http://www.canmart.co.kr/shopimages/jason006/0790010157183.gif?1657247342" class="card-img-top" alt="..."></a>
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">219,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790010157023.gif?1656999880" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">119,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790040045833.gif?1657504851" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">129,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790020035733.gif?1657499032" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">249,900원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790040045853.gif?1657504265" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">219,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790050040803.gif?1657677482" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">119,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790010157173.jpg?1657176716" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">129,000원</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card" style="width: 18rem;">
            <img src="http://www.canmart.co.kr/shopimages/jason006/0790150030013.gif?1657679542" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">벨유_프리미엄텐션티 MA05184</h5>
              <p class="card-text">
                <span class="badge bg-dark p-2 m-1">전상품 10%</span>
                <span class="badge bg-dark p-2 m-1">주문폭주</span>
                <span class="badge bg-dark p-2 m-1">NEW</span>
              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                </div>
                <small class="text-dark">249,900원</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>
