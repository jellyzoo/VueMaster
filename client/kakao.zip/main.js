import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import mixins from './mixins'

createApp(App).use(router).mixin(mixins).use(store).mount('#app')

//import 'bootstrap'
//import 'bootstrap/dist/css/bootstrap.min.css'

window.Kakao.init("6e37a398287f9f4ddb22ec316416ef93");